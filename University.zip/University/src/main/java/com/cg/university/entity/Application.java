package com.cg.university.entity;

import java.sql.Date;


import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.SequenceGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@Entity
@JsonIgnoreProperties("handler")
public class Application {
	  @Id	  
	  @Column(name="applicationId")	  
	  @SequenceGenerator(name="applicationseq",
	  sequenceName="application_seq",initialValue= 100,allocationSize=1)	  
	  @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="applicationseq")
		private int applicationId;
		private String fullName;
		private String dateOfBirth;
		private String highestQualification;
		private int marksObtained;
		private String goals;
		private String emailID;
		
		@Column(name="status")
		private String status="applied"; 
	
		private String dateOfInterview;
		private int scheduledProgramID;
	/*
	 * @ManyToOne(fetch = FetchType.LAZY, cascade= CascadeType.ALL)
	 * 
	 * @JoinColumn(name ="scheduledProgramID") private ProgramsScheduled
	 * programsScheduled;
	 */
	
	
	
	
}